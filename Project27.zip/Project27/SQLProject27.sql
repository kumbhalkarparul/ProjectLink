create table Login_Project
(
	
	LoginID varchar(50) not null,
	Password varchar(50)
)

select * from Login_Project


drop table Login_Project
insert into Login_Project values ('Parul','Parul1234')

create procedure Login_Procedure_Project
(@loginid varchar(50),@password varchar(50))
 as begin 
 select * from  Login_Project where LoginID=@loginid and Password=@password
 end
 drop proc Login_Procedue_Project


 create table Travel_Booking
 (
	UserID  int identity(1000,1) not null,

	DateOfBooking datetime not null,
	FromLocation varchar(50) not null,
	ToLocation varchar(50) not null
 )