create table Login_Project
(
	
	LoginID varchar(50) not null,
	Password varchar(50)
)

select * from Login_Project


drop table Login_Project
insert into Login_Project values ('Parul','Parul1234')

create procedure Login_Procedure_Project
(@loginid varchar(50),@password varchar(50))
 as begin 
 select * from  Login_Project where LoginID=@loginid and Password=@password
 end
 drop proc Login_Procedue_Project
 drop table Travel_Booking

 create table Travel_Booking
 (
	EmpID  int identity(1000,1) not null,
	RequestId int not null,
	RequestDate datetime not null,
	FromLocation varchar(50) not null,
	ToLocation varchar(50) not null,
	CurrentStatus varchar(50)
 )
 select *from Travel_Booking

 insert into Travel_Booking values(1,'11/17/2018','Nagpur','Pune','Accepted')
 insert into Travel_Booking values(2,'11/18/2018','Hydrebad','Pune','Accepted') 
 create procedure Travel_Booking_27(@empid int,@reqdate datetime, @frmloc varchar(50),@toloc varchar(50))
  as begin 
  select EmpID,RequestDate,FromLocation,ToLocation from Travel_Booking
  where EmpID=@empid and RequestDate=@reqdate and FromLocation=@frmloc and ToLocation=@toloc
  
 end