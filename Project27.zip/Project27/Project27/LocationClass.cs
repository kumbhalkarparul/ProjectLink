﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project27
{
    public class LocationClass
    {
        public enum FromLocation
        {
            Nagpur,Hydrebad
        }
        public enum ToLocation
        {
            Pune
        }
    }
}
