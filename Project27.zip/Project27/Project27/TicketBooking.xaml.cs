﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Project27
{
    /// <summary>
    /// Interaction logic for TicketBooking.xaml
    /// </summary>
    public partial class TicketBooking : Window
    {
        public TicketBooking()
        {
            InitializeComponent();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string ConStr = ConfigurationManager.ConnectionStrings["ConStr"].ConnectionString;
            SqlConnection con = new SqlConnection(ConStr);
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "Travel_Booking_27";
            cmd.Connection = con;
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();

            cmd.Parameters.AddWithValue("@empid", Convert.ToInt32(txtEmpID.Text));
            cmd.Parameters.AddWithValue("@reqdate", txtDate.SelectedDate);
            cmd.Parameters.AddWithValue("@frmloc", cmbfromLocation.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@toloc", cmbtoLocation.SelectedValue.ToString());


            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                MessageBox.Show("Logged in");
                var win2 = new Employee();
                win2.Show();
            }
            else
            {
                MessageBox.Show("Details not matched");
            }
            con.Close();

        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            foreach(var item in Enum.GetValues(typeof(FromLocation)))
            {
                cmbfromLocation.Items.Add(item);
            }
            foreach (var item in Enum.GetValues(typeof(ToLocation)))
            {
                cmbtoLocation.Items.Add(item);
            }
        }
    }
    enum FromLocation
    {
        Nagpur, Hydrebad
    }
    enum ToLocation
    {
        Pune
    }
}
