﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankConsumer
{
    public partial class Consumer : Form
    {
        public Consumer()
        {
            InitializeComponent();
        }
        ServiceReference1.BankClient b1 = new ServiceReference1.BankClient("NetTcpBinding_IBank");
        private void btnclient_Click(object sender, EventArgs e)
        {
           
            MessageBox.Show(b1.Deposit());
        }
    }
}
