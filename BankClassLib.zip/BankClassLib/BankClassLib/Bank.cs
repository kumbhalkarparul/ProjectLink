﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BankClassLib
{
    public class Bank : IBank
    {
        public string Deposit()
        {
            return "Deposited on" + DateTime.Now.ToString();
        }
        public string Withdraw()
        {
            return "Withdraw on" + DateTime.Now.ToString();
        }
    }
}
