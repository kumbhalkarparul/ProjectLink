﻿using System.ServiceModel;
namespace BankApplicationClassLib
{
    [ServiceContract]
    public interface IBank
    {
        [OperationContract]

        string Deposit();

        [OperationContract]

        string Withdraw();
        [OperationContract]

        string Increment();
        
    }
}