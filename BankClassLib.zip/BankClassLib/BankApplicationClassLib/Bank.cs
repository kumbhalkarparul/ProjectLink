﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace BankApplicationClassLib
{
    [ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession)]
    public class Bank : IBank
    {
        int count = 0;
        public string Deposit()
        {
            return "Deposited on" + DateTime.Now.ToString();
        }
        public string Increment()
        {
            return "Increment on" + DateTime.Now.ToString()+count++;
        }
        public string Withdraw()
        {
            return "Withdraw on" + DateTime.Now.ToString();
        }
    }
}
