﻿using BankApplicationClassLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BankHost
{
    public partial class Host : Form
    {
        public Host()
        {
            InitializeComponent();
        }

        private void btnHost_Click(object sender, EventArgs e)
        {
            ServiceHost sv = new ServiceHost(typeof(Bank));
            sv.Open();
            MessageBox.Show(sv.State.ToString());
        }
    }
}
